 #include <stdio.h>
  #include <stdlib.h>
 
  #define OK 1
  #define ERROR 0
  #define OVERFLOW -2
  #define TRUE 1
  #define FALSE 0
  
 typedef int Status;
 typedef int ElemType;
 
 typedef struct LNode{
     ElemType data;
     struct LNode *next;
 }*Link, *Position;
 typedef struct{
     Link head, tail;
     int len;
 }LinkList;
 
 Status InitList(LinkList &L){
     L.head = (Link)malloc(sizeof(LNode));
     if(!L.head)
         exit(OVERFLOW);
     L.tail = L.head;
     L.len = 0;
     L.head->next = NULL;
     return 0;
 }
 
 Status MakeNode(Link &p,ElemType e){
     p = (Link)malloc(sizeof(LNode));
     if(!p)
         exit(OVERFLOW);
     p->data = e;
     p->next = NULL;
     return OK;
 }
 
 Status Append(LinkList &L, Link S){
     Link p;
     L.tail->next = S;
     p = S;
     ++L.len;
     while(p->next){
         p = p->next;
         ++L.len;
     }
     L.tail = p;
     return OK;
 }