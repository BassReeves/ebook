#include<stdio.h>  
#include<stdlib.h>  
#include<malloc.h>  
#include<string.h>  
#define MAX 100  
#define INF (~(0x1<<31))  
typedef struct Graph  
{  
    char vexs[MAX];  
    int vexnum;  
    int edgnum;  
    int matrix[MAX][MAX];  
} Graph,*PGraph;  
  
typedef struct EdgeData  
{  
    char start;  
    char end;  
    int weight;  
} EData;  
  
static int get_position(Graph g,char ch)  
{  
    int i;  
    for(i=0; i<g.vexnum; i++)  
        if(g.vexs[i]==ch)  
            return i;  
    return -1;  
}  
  
Graph* create_graph()  
{  
    char vexs[]= {'A','B','C','D','E','F','G'};  
    int matrix[][7]=  
    {  
        {0,12,INF,INF,INF,16,14},  
        {12,0,10,INF,INF,7,INF},  
        {INF,10,0,3,5,6,INF},  
        {INF,INF,3,0,4,INF,INF},  
        {INF,INF,5,4,0,INF,8},  
        {16,7,6,INF,2,0,9},  
        {14,INF,INF,INF,8,9,0}  
    };  
    int vlen=sizeof(vexs)/sizeof(vexs[0]);  
    int i,j;  
    Graph *pG;  
    if((pG=(Graph*)malloc(sizeof(Graph)))==NULL)  
        return NULL;  
    memset(pG,0,sizeof(pG));  
    pG->vexnum=vlen;  
    for(i=0; i<pG->vexnum; i++)  
        pG->vexs[i]=vexs[i];  
    for(i=0; i<pG->vexnum; i++)  
        for(j=0; j<pG->vexnum; j++)  
            pG->matrix[i][j]=matrix[i][j];  
    for(i=0; i<pG->vexnum; i++)  
    {  
        for(j=0; j<pG->vexnum; j++)  
        {  
            if(i!=j&&pG->matrix[i][j]!=INF)  
                pG->edgnum++;  
        }  
    }  
    pG->edgnum/=2;  
    return pG;  
}  
  
void print_graph(Graph G)  
{  
    int i,j;  
    printf("Matrix Graph: \n");  
    for(i=0; i<G.vexnum; i++)  
    {  
        for(j=0; j<G.vexnum; j++)  
            printf("%10d ",G.matrix[i][j]);  
        printf("\n");  
    }  
}  
  
EData* get_edges(Graph G)  
{  
    EData *edges;  
    edges=(EData*)malloc(G.edgnum*sizeof(EData));  
    int i,j;  
    int index=0;  
    for(i=0; i<G.vexnum; i++)  
    {  
        for(j=i+1; j<G.vexnum; j++)  
        {  
            if(G.matrix[i][j]!=INF)  
            {  
                edges[index].start=G.vexs[i];  
                edges[index].end=G.vexs[j];  
                edges[index].weight=G.matrix[i][j];  
                index++;  
            }  
        }  
    }  
    return edges;  
}  
  
void prim(Graph G,int start)  
{  
    int min,i,j,k,m,n,sum;  
    int index=0;  
    char prim[MAX];  
    int weight[MAX];  
  
    prim[index++]=G.vexs[start];  
  
    for(i=0; i<G.vexnum; i++)  
        weight[i]=G.matrix[start][i];  
    weight[start]=0;  
  
    for(i=0; i<G.vexnum; i++)  
    {  
       //i��������ѭ���Ĵ�����ÿ�μ���һ����㣬������Ϊstart�Ѿ����룬���Ե�iΪstart������  
        if(start==i)  
            continue;  
        j=0;  
        k=0;  
        min=INF;  
        for(k=0; k<G.vexnum; k++)  
        {  
            if(weight[k]&&weight[k]<min)  
            {  
                min=weight[k];  
                j=k;  
            }  
        }  
        sum+=min;  
        prim[index++]=G.vexs[j];  
        weight[j]=0;  
        for(k=0; k<G.vexnum; k++)  
        {  
            if(weight[k]&&G.matrix[j][k]<weight[k])  
                weight[k]=G.matrix[j][k];  
        }  
    }  
    // ������С��������Ȩֵ  
    sum = 0;  
    for (i = 1; i < index; i++)  
    {  
        min = INF;  
        // ��ȡprims[i]��G�е�λ��  
        n = get_position(G, prim[i]);  
        // ��vexs[0...i]�У��ҳ���j��Ȩֵ��С�Ķ��㡣  
        for (j = 0; j < i; j++)  
        {  
            m = get_position(G, prim[j]);  
            if (G.matrix[m][n]<min)  
                min = G.matrix[m][n];  
        }  
        sum += min;  
    }  
    printf("PRIM(%c)=%d: ", G.vexs[start], sum);  
    for (i = 0; i < index; i++)  
        printf("%c ", prim[i]);  
    printf("\n");  
}  
  
int main()  
{  
    Graph *pG;  
    pG=create_graph();  
    print_graph(*pG);  
    prim(*pG,0);  
} 